package com.ldts.breakout.state;

public class InstructionsState {
}
