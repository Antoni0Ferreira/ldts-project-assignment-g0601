package com.ldts.breakout.model;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.ldts.breakout.Constants;

public class Wall extends Element {

    public Wall(Position position) {
        super(position);
    }

}
