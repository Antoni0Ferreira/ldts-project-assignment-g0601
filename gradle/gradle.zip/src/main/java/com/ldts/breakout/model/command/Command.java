package com.ldts.breakout.model.command;

public interface Command {
    boolean execute();
    void undo();
}