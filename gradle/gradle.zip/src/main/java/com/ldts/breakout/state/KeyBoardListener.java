package com.ldts.breakout.state;

import com.ldts.breakout.gui.GUI;

public interface KeyBoardListener {
    void keyPressed(GUI.ACTION action);
}
