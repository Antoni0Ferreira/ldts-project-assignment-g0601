package com.ldts.breakout.model;

public interface Model {
}
